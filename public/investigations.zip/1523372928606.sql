/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50556
Source Host           : localhost:3306
Source Database       : secure_bridge

Target Server Type    : MYSQL
Target Server Version : 50556
File Encoding         : 65001

Date: 2018-03-27 15:31:02
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for news
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `body` longtext,
  `photo` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES ('1', 'الخبر الاول ', 'نص الخبر الاول ', null, '1', '2018-03-21 18:23:10', '2018-03-21 18:23:10', '2018-03-21 18:23:10', null, null);
INSERT INTO `news` VALUES ('2', 'الخبر التاني ', 'نص الخبر التاني ', null, '1', '2018-03-21 18:23:10', '2018-03-21 18:23:10', '2018-03-21 18:23:10', null, null);
INSERT INTO `news` VALUES ('3', 'الخبر التالت ', 'نص الخبر التالت', null, '1', '2018-03-21 18:23:10', '2018-03-21 18:23:10', '2018-03-21 18:23:10', null, null);
INSERT INTO `news` VALUES ('4', 'الخر الرابع ', 'نص الخبر الرابع', null, '0', '2018-03-21 18:23:11', '2018-03-21 18:23:11', '2018-03-21 18:23:11', null, null);
