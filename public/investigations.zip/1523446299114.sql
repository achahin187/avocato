ALTER TABLE `user_details`
ADD COLUMN `litigation_level`  varchar(255) NULL AFTER `syndicate_level`;