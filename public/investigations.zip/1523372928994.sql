/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50556
Source Host           : localhost:3306
Source Database       : secure_bridge

Target Server Type    : MYSQL
Target Server Version : 50556
File Encoding         : 65001

Date: 2018-03-27 13:00:06
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for consultation_types
-- ----------------------------
DROP TABLE IF EXISTS `consultation_types`;
CREATE TABLE `consultation_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of consultation_types
-- ----------------------------
INSERT INTO `consultation_types` VALUES ('1', 'خمور', '2018-03-26 14:34:56', '2018-03-26 14:34:56');
INSERT INTO `consultation_types` VALUES ('2', 'مرور', '2018-03-26 14:35:02', '2018-03-26 14:35:02');
INSERT INTO `consultation_types` VALUES ('3', 'قتل', '2018-03-26 14:35:09', '2018-03-26 14:35:09');
INSERT INTO `consultation_types` VALUES ('4', 'سرقة', '2018-03-26 14:35:18', '2018-03-26 14:35:18');
INSERT INTO `consultation_types` VALUES ('5', 'تشهيير', '2018-03-26 14:35:24', '2018-03-26 14:35:24');
